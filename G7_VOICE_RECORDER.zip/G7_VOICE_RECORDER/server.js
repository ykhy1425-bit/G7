require("dotenv").config();
const express = require("express");
const fs = require("fs");
const path = require("path");
const {
  Client, GatewayIntentBits, ChannelType, PermissionsBitField
} = require("discord.js");
const {
  joinVoiceChannel, getVoiceConnection, EndBehaviorType
} = require("@discordjs/voice");
const prism = require("prism-media");
const wav = require("wav");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const AUDIO_DIR = path.join(ROOT, "recordings", "audio");
fs.mkdirSync(AUDIO_DIR, { recursive: true });
app.use(express.json({ limit: "1mb" }));

// Protect the entire dashboard and its API with HTTP Basic Authentication.
// Set ADMIN_USER and ADMIN_PASSWORD in the hosting provider's environment.
const ADMIN_USER = process.env.ADMIN_USER;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && require("crypto").timingSafeEqual(aa, bb);
}
app.use((req, res, next) => {
  if (!ADMIN_USER || !ADMIN_PASSWORD) {
    return res.status(503).send("G7 dashboard is not configured: set ADMIN_USER and ADMIN_PASSWORD on the host.");
  }
  const header = req.headers.authorization || "";
  if (!header.startsWith("Basic ")) {
    res.set("WWW-Authenticate", 'Basic realm="G7 VOICE RECORDER", charset="UTF-8"');
    return res.status(401).send("Authentication required");
  }
  let decoded = "";
  try { decoded = Buffer.from(header.slice(6), "base64").toString("utf8"); } catch {}
  const splitAt = decoded.indexOf(":");
  const user = splitAt >= 0 ? decoded.slice(0, splitAt) : "";
  const pass = splitAt >= 0 ? decoded.slice(splitAt + 1) : "";
  if (!safeEqual(user, ADMIN_USER) || !safeEqual(pass, ADMIN_PASSWORD)) {
    res.set("WWW-Authenticate", 'Basic realm="G7 VOICE RECORDER", charset="UTF-8"');
    return res.status(401).send("Invalid credentials");
  }
  next();
});
app.use(express.static(path.join(ROOT, "public")));

let client = null;
let activeGuild = null;
let activeChannelId = null;
let archiveChannelId = process.env.ARCHIVE_CHANNEL_ID || null;
let noticeChannelId = process.env.NOTICE_CHANNEL_ID || null;
let recorderConnection = null;
let botState = { connected: false, username: null, guildName: null, error: null };
let eventLog = [];
let monitoredUsers = new Set();
let noticePromises = new Map();

function logEvent(type, message) {
  const entry = { at: new Date().toISOString(), type, message };
  eventLog.unshift(entry);
  eventLog = eventLog.slice(0, 150);
  console.log(`[${type}] ${message}`);
}

function safeName(value) {
  return String(value || "unknown").replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 50);
}

async function notifyParticipant(userId) {
  if (noticePromises.has(userId)) return noticePromises.get(userId);
  const task = (async () => {
    try {
      const user = await client.users.fetch(userId);
      await user.send("تنبيه من إدارة G7: هذا الروم الصوتي يخضع لتسجيل صوتي لأغراض التوثيق والسلامة. قد تُحفظ المقاطع في أرشيف السيرفر وفق سياسة التسجيل المعلنة.");
      logEvent("notice", `Recording notice delivered by DM to ${user.tag}`);
      return true;
    } catch (err) {
      logEvent("warning", `Could not DM recording notice to ${userId}; audio capture skipped for this member (${err.message})`);
      return false;
    }
  })();
  noticePromises.set(userId, task);
  const ok = await task;
  return ok;
}

async function archiveAudio(filename, outPath, userLabel, channelId) {
  if (!archiveChannelId || !activeGuild) {
    logEvent("warning", `Audio saved locally but not sent to Discord: archive channel is not configured (${filename})`);
    return;
  }
  try {
    const archive = await activeGuild.channels.fetch(archiveChannelId);
    if (!archive?.isTextBased() || !archive.send) throw new Error("Archive channel is not a sendable text channel.");
    await archive.send({
      content: `**G7 VOICE ARCHIVE**\nالمتحدث: ${userLabel}\nروم الصوت: <#${channelId}>\nالملف: ${filename}`,
      files: [{ attachment: outPath, name: filename }]
    });
    logEvent("archive", `Uploaded ${filename} to Discord archive channel.`);
  } catch (err) {
    logEvent("error", `Discord archive upload failed for ${filename}: ${err.message}. File remains on host.`);
  }
}

async function startUserRecording(userId, channelId) {
  if (!recorderConnection || !recorderConnection.receiver) return;
  const notified = await notifyParticipant(userId);
  if (!notified) return;
  if (monitoredUsers.has(userId)) return;
  if (!recorderConnection || !recorderConnection.receiver) return;
  const user = client?.users?.cache?.get(userId);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const filename = `${stamp}_${safeName(user?.username || userId)}_${safeName(userId)}.wav`;
  const outPath = path.join(AUDIO_DIR, filename);

  try {
    const opusStream = recorderConnection.receiver.subscribe(userId, {
      end: { behavior: EndBehaviorType.AfterSilence, duration: 1200 }
    });
    const decoder = new prism.opus.Decoder({
      rate: 48000, channels: 2, frameSize: 960
    });
    const writer = new wav.Writer({
      channels: 2, sampleRate: 48000, bitDepth: 16
    });

    opusStream.pipe(decoder).pipe(writer);
    const output = fs.createWriteStream(outPath);
    writer.pipe(output);
    monitoredUsers.add(userId);

    opusStream.once("error", err => logEvent("warning", `Audio stream issue: ${err.message}`));
    output.once("finish", async () => {
      monitoredUsers.delete(userId);
      if (fs.existsSync(outPath) && fs.statSync(outPath).size > 44) {
        logEvent("audio", `Saved ${filename}`);
        await archiveAudio(filename, outPath, user?.tag || user?.username || userId, channelId);
      } else {
        try { fs.unlinkSync(outPath); } catch {}
      }
    });
    logEvent("audio", `Started audio segment for ${user?.username || userId}`);
  } catch (err) {
    logEvent("error", `Could not record user ${userId}: ${err.message}`);
  }
}

async function joinMonitoredChannel(channelId) {
  if (!client || !activeGuild) throw new Error("Connect the bot first.");
  const channel = await activeGuild.channels.fetch(channelId);
  if (!channel || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)) {
    throw new Error("The selected channel is not a voice channel.");
  }
  const me = activeGuild.members.me;
  const perms = channel.permissionsFor(me);
  if (!perms?.has(PermissionsBitField.Flags.Connect) ||
      !perms?.has(PermissionsBitField.Flags.ViewChannel)) {
    throw new Error("The bot needs View Channel and Connect permissions in this room.");
  }
  if (recorderConnection) {
    try { recorderConnection.destroy(); } catch {}
  }
  activeChannelId = channelId;
  recorderConnection = joinVoiceChannel({
    channelId,
    guildId: activeGuild.id,
    adapterCreator: activeGuild.voiceAdapterCreator,
    selfDeaf: false,
    selfMute: true
  });
  recorderConnection.receiver.speaking.on("start", userId => {
    if (userId !== client.user.id) startUserRecording(userId, channelId);
  });
  logEvent("system", `Recorder joined #${channel.name}. Only one room per Discord server can be monitored by this bot account at a time.`);
  if (noticeChannelId) {
    try {
      const noticeChannel = await activeGuild.channels.fetch(noticeChannelId);
      if (!noticeChannel?.isTextBased() || !noticeChannel.send) throw new Error("Notice channel is not a sendable text channel.");
      await noticeChannel.send(`**G7 VOICE RECORDER**\nبدأ توثيق الصوت في <#${channelId}>. سيتم إرسال إشعار خاص للمشاركين قبل التقاط صوتهم. راجعوا سياسة التسجيل والاحتفاظ بالتسجيلات لدى الإدارة.`);
    } catch (err) {
      logEvent("warning", `Could not post public recording notice: ${err.message}`);
    }
  }
  for (const member of channel.members.values()) {
    if (!member.user.bot) notifyParticipant(member.id);
  }
  return channel;
}

async function connectBot(token, guildId, archiveId = archiveChannelId, noticeId = noticeChannelId) {
  archiveChannelId = archiveId || null;
  noticeChannelId = noticeId || null;
  if (client) {
    try { client.destroy(); } catch {}
    client = null;
  }
  botState = { connected: false, username: null, guildName: null, error: null };
  const next = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildVoiceStates,
      GatewayIntentBits.GuildMembers
    ]
  });
  client = next;

  next.on("ready", async () => {
    try {
      activeGuild = await next.guilds.fetch(guildId);
      botState = {
        connected: true,
        username: next.user.tag,
        guildName: activeGuild.name,
        error: null
      };
      logEvent("system", `Bot connected as ${next.user.tag}; server: ${activeGuild.name}`);
    } catch (err) {
      botState.error = `Could not access server: ${err.message}`;
      logEvent("error", botState.error);
    }
  });

  next.on("voiceStateUpdate", (oldState, newState) => {
    if (newState.guild.id !== guildId) return;
    if (oldState.channelId !== newState.channelId && newState.channelId) {
      logEvent("member", `${newState.member?.user?.tag || newState.id} joined a voice room`);
    }
    if (oldState.channelId && oldState.channelId !== newState.channelId) {
      logEvent("member", `${oldState.member?.user?.tag || oldState.id} left a voice room`);
    }
    // Discord exposes stream/video state flags, but does not provide the actual
    // screen-share video stream to ordinary bots.
    if (!oldState.streaming && newState.streaming) {
      logEvent("share", `${newState.member?.user?.tag || newState.id} started screen sharing (event only; video is not captured)`);
    } else if (oldState.streaming && !newState.streaming) {
      logEvent("share", `${oldState.member?.user?.tag || oldState.id} stopped screen sharing`);
    }
    if (newState.channelId === activeChannelId && oldState.channelId !== newState.channelId) {
      logEvent("member", `Member entered the monitored room: ${newState.member?.user?.tag || newState.id}`);
      if (!newState.member?.user.bot) notifyParticipant(newState.id);
    }
    if (oldState.channelId === activeChannelId && oldState.channelId !== newState.channelId) {
      noticePromises.delete(oldState.id);
    }
  });

  next.on("error", err => {
    botState.error = err.message;
    logEvent("error", err.message);
  });
  await next.login(token);
  return next;
}

app.get("/api/status", (_req, res) => {
  res.json({
    bot: botState,
    activeChannelId,
    recordingFiles: fs.readdirSync(AUDIO_DIR).filter(f => f.endsWith(".wav")).length,
    events: eventLog.slice(0, 12)
  });
});

app.post("/api/connect", async (req, res) => {
  const { token, guildId, archiveId, noticeId } = req.body || {};
  if (!token || !guildId || !archiveId || !noticeId) return res.status(400).json({ error: "أدخل التوكن وID السيرفر وروم الأرشيف وروم الإشعارات." });
  try {
    // Store credentials locally on the Windows host, never in browser storage.
    const envPath = path.join(ROOT, ".env");
    const existingPort = process.env.PORT || "3000";
    fs.writeFileSync(envPath,
      `DISCORD_TOKEN=${JSON.stringify(token)}\nGUILD_ID=${JSON.stringify(guildId)}\nARCHIVE_CHANNEL_ID=${JSON.stringify(archiveId)}\nNOTICE_CHANNEL_ID=${JSON.stringify(noticeId)}\nPORT=${existingPort}\n`,
      { mode: 0o600 }
    );
    process.env.DISCORD_TOKEN = token;
    process.env.GUILD_ID = guildId;
    process.env.ARCHIVE_CHANNEL_ID = archiveId;
    process.env.NOTICE_CHANNEL_ID = noticeId;
    await connectBot(token, guildId, archiveId, noticeId);
    res.json({ ok: true, message: "Login requested. The bot will appear connected when Discord confirms it." });
  } catch (err) {
    botState.error = err.message;
    res.status(400).json({ error: err.message });
  }
});

app.get("/api/channels", async (_req, res) => {
  if (!activeGuild) return res.status(400).json({ error: "Connect the bot first." });
  try {
    const channels = await activeGuild.channels.fetch();
    res.json(channels.filter(c =>
      c && [ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(c.type)
    ).map(c => ({ id: c.id, name: c.name, members: c.members?.size || 0 })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/monitor", async (req, res) => {
  const { channelId } = req.body || {};
  if (!channelId) return res.status(400).json({ error: "Choose a voice room." });
  try {
    const channel = await joinMonitoredChannel(channelId);
    res.json({ ok: true, channel: channel.name });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/stop", (_req, res) => {
  if (recorderConnection) {
    try { recorderConnection.destroy(); } catch {}
    recorderConnection = null;
    activeChannelId = null;
    logEvent("system", "Voice recording connection stopped.");
  }
  res.json({ ok: true });
});

app.get("/api/recordings", (_req, res) => {
  const files = fs.readdirSync(AUDIO_DIR)
    .filter(f => f.endsWith(".wav"))
    .map(name => {
      const stat = fs.statSync(path.join(AUDIO_DIR, name));
      return { name, size: stat.size, modified: stat.mtime.toISOString(), url: `/recordings/${encodeURIComponent(name)}` };
    })
    .sort((a,b) => b.modified.localeCompare(a.modified));
  res.json(files);
});

app.get("/recordings/:name", (req, res) => {
  const name = path.basename(req.params.name);
  if (!name.endsWith(".wav")) return res.sendStatus(404);
  const file = path.join(AUDIO_DIR, name);
  if (!fs.existsSync(file)) return res.sendStatus(404);
  res.sendFile(file);
});

app.get("/api/events", (_req, res) => res.json(eventLog));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`G7 VOICE RECORDER running on http://localhost:${PORT}`);
  if (process.env.DISCORD_TOKEN && process.env.GUILD_ID) {
    connectBot(process.env.DISCORD_TOKEN, process.env.GUILD_ID, process.env.ARCHIVE_CHANNEL_ID, process.env.NOTICE_CHANNEL_ID).catch(err => {
      botState.error = err.message;
      logEvent("error", err.message);
    });
  }
});
